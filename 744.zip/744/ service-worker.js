const CACHE_NAME = "ai-744-v1";
const URLS = ["./", "./index.html"];

self.addEventListener("install", (e)=>{
  e.waitUntil(caches.open(CACHE_NAME).then(c=>c.addAll(URLS)));
  self.skipWaiting();
});

self.addEventListener("activate", (e)=>{
  e.waitUntil(
    caches.keys().then(keys => Promise.all(
      keys.filter(k => k !== CACHE_NAME).map(k => caches.delete(k))
    ))
  );
  self.clients.claim();
});

self.addEventListener("fetch", (e)=>{
  const url = new URL(e.request.url);
  if(url.hostname.includes("deepseek") || url.hostname.includes("open-meteo")) return;
  e.respondWith(
    caches.match(e.request).then(r => r || fetch(e.request).then(res=>{
      if(e.request.method === "GET" && url.origin === location.origin){
        const clone = res.clone();
        caches.open(CACHE_NAME).then(c => c.put(e.request, clone));
      }
      return res;
    }))
  );
});